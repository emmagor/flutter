package com.example.hola_mundo_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
